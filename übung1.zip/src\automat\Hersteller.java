package automat;

public interface Hersteller {
    String getName();
}

