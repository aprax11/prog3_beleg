package automat;

public enum Allergen {
    Gluten,Erdnuss,Haselnuss,Sesamsamen
}

