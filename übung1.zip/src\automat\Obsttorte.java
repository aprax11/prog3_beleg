package automat;

public interface Obsttorte extends Obstkuchen,Kremkuchen {
}

