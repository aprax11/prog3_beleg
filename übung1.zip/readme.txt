bis einschließlich 16.

Anmerkungen:
Da ich mich bemüht habe die Geschäftslogik schon möglichst zu kapseln
hatte ich schwierigkeiten die Testobjekte zu mocken. Aus diesem Grund habe ich nur die
Herstellerobjekte gemockt ich hoffe das ist nicht schlimm.
zu 16:
Ich habe einige der Einfügetest auch mit mockito geschrieben 
und z.B das einfügen aller Kuchentypen und die die fortlaufende Vergabe der Fachnummern
in einem Test untergebracht. Ich habe zudem versucht Codeduplikate zu vermeiden, aber
ich glaube ganz ohne habe ich es nicht geschafft. Daher habe ich auch nicht angegeben, dass
ich Nummer 17 absolviert hätte.